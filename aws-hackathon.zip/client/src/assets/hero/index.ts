import copy from "./copy-dynamic-gradientasset.svg";
import folder from "./folder-dynamic-gradientasset.svg";
import gift from "./gift-dynamic-gradientasset.svg";
import location from "./location-dynamic-gradientasset.svg";
import mail from "./mail-dynamic-gradientasset.svg";
import music from "./music-dynamic-gradientasset.svg";
import notebook from "./notebook-dynamic-gradientasset.svg";
import picture from "./picture-dynamic-gradientasset.svg";
import shield from "./sheild-dynamic-gradientasset.svg";

export {
    copy,
    folder,
    gift,
    location,
    mail,
    music,
    notebook,
    picture,
    shield,
};
