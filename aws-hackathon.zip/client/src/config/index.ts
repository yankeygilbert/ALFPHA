export default {
    NODE_ENV: import.meta.env.VITE_NODE_ENV,
    // Server variables
    HOST: import.meta.env.VITE_SERVER_HOST,
    SERVER_PORT: import.meta.env.VITE_SERVER_PORT,
}