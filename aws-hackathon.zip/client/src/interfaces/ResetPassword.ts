export interface ResetPasswordModule {
  token: string | null;
  id: string | null;
  password: string;
}
